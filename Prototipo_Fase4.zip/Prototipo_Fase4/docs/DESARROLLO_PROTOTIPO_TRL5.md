# Desarrollo del prototipo funcional (TRL5) — sección para el documento maestro



## 1. Metodología de desarrollo aplicada: prototipado incremental

Se mantiene el modelo de prototipado incremental del documento maestro (Sommerville, 2011): cada incremento agrega
una capacidad, se prueba y se evalúa antes de pasar al siguiente. Como la guía de la Fase 4 pide identificar
metodologías ágiles, el trabajo se organiza en iteraciones cortas con una lista priorizada de requerimientos
(prioridad Alta primero), revisión al final de cada iteración y ajuste del siguiente. Esto es una adaptación
práctica de principios ágiles (entrega incremental, retroalimentación temprana, prioridades) para un equipo de dos personas.

| Iteración | Incremento (doc. maestro) | Qué se entrega | Requerimientos | Evidencia |
|---|---|---|---|---|
| 1 | Lectura y registro de humedad | Lectura del sensor con promedio, conversión a %, validación y registro CSV | RF1, RF5 | Pruebas 1.x y archivo de registro |
| 2 | Control automático por umbrales con relé | Máquina de estados con histéresis, modos AUTO/MANUAL/PARADA, tiempo máximo de bombeo, falla de sensor | RF2, RF3, RF4, RF7, RNF3 | Pruebas automáticas (38) y pruebas con relé |
| 3 | Comunicación y monitoreo | Wi-Fi, MQTT, comandos remotos, estado publicado, operación sin red | RF6, RNF4 | Pruebas con broker y tablero |

**[COMPLETAR]** fechas reales de cada iteración y una frase de la retrospectiva (qué se ajustó tras cada una).

## 2. Análisis de requerimientos y trazabilidad

Los requerimientos son los de la Tabla 7 del documento maestro (Fase 3). Cada uno se traza a un módulo y a una prueba.

| ID | Requerimiento (resumen) | Módulo / función | Verificación |
|---|---|---|---|
| RF1 | Medir humedad a intervalos configurables | `medirHumedad()`, `sensor_utils.h`, comando `intervalo_s` | Prueba automática de conversión y promedio; prueba 1.1 en campo |
| RF2 | Umbral inferior y superior configurables | `ControlRiego::configurar()`, comandos `umbral_inf` / `umbral_sup` | Pruebas automáticas de histéresis y validación |
| RF3 | Activar riego bajo el umbral inferior | `ControlRiego::actualizar()` | Prueba automática y prueba 2.1 con relé |
| RF4 | Desactivar al alcanzar el umbral superior | `ControlRiego::actualizar()` | Prueba automática y prueba 2.2 |
| RF5 | Registrar lecturas, hora y eventos | `registro.h` | Prueba 1.3: comando `volcar` y revisión del CSV |
| RF6 | Monitoreo si hay conectividad | `comunicacion.h` | Prueba 3.1 con broker MQTT |
| RF7 | Modo manual o parada | `Modo::MANUAL_ON` / `PARADA` | Pruebas automáticas y prueba 2.4 |
| RNF1 | Bajo costo, disponible en Colombia | Lista de componentes (Tabla 9 del doc. maestro) | Comparar costo real con lo presupuestado **[COMPLETAR]** |
| RNF2 | Aislar control y potencia, proteger del agua | Relé, fuente separada, caja | Inspección y foto del montaje **[COMPLETAR]** |
| RNF3 | Operar seguro ante fallas | Falla de sensor y `tMaxBombeoMs` | Pruebas automáticas y prueba 2.5 (sensor desconectado) |
| RNF4 | Acceso protegido; sin identificar productores | `secrets.h`, usuario y clave MQTT; el mensaje solo lleva datos del suelo | Revisión del código y del mensaje publicado |
| RNF5 | Diseño modular | Un archivo por responsabilidad; lógica sin hardware | Las pruebas compilan la lógica sin el ESP32 |

## 3. Diseño integral del prototipo

**Arquitectura (capas):** sensado (sensor capacitivo → ADC GPIO34), procesamiento (ESP32: promedio, conversión,
máquina de estados), actuación (GPIO26 → relé → bomba o electroválvula), comunicación (Wi-Fi → MQTT) y aplicación
(tablero de monitoreo y registro local en CSV).

**Máquina de estados del control** (`control_riego.h`):

- `REPOSO`: relé apagado. Si humedad < umbral inferior (y modo AUTO) pasa a `REGANDO`.
- `REGANDO`: relé encendido. Pasa a `REPOSO` al alcanzar el umbral superior; pasa a `BLOQUEO_TIEMPO` si el bombeo continuo supera el tiempo máximo.
- `BLOQUEO_TIEMPO`: relé apagado durante una espera obligatoria, luego vuelve a `REPOSO`.
- `FALLA_SENSOR`: lectura inválida (sensor desconectado, en corto o con menos de la mitad de lecturas válidas): relé apagado hasta que el sensor se recupere.
- Modo `PARADA` apaga siempre; `MANUAL_ON` fuerza el riego pero sigue sujeto al tiempo máximo y a la falla de sensor.

**Decisiones de diseño:** histéresis de dos umbrales para evitar encendidos repetidos; relé que arranca siempre apagado;
lógica de decisión sin dependencias de hardware para probarla automáticamente; parámetros y calibración guardados en la
memoria no volátil; control que no depende del Wi-Fi ni del registro (si fallan, el riego por umbrales continúa).

## 4. Desarrollo del prototipo y evidencia de nivel TRL5

TRL5 significa que el prototipo integrado se valida en un entorno relevante (cercano al real). Para este proyecto,
el entorno relevante es el suelo y el cultivo de prueba de la vereda o, si no es viable, un entorno controlado equivalente
(maceta o parcela con el mismo suelo), como declara el documento maestro.

| Nivel | Qué lo demuestra | Estado |
|---|---|---|
| TRL3-4: concepto y componentes validados | Lógica de control con 38 pruebas automáticas; simulación de 4 escenarios; sintaxis del firmware verificada contra stubs del núcleo Arduino | **Hecho** (ver repositorio) |
| TRL4: integración en laboratorio | ESP32 + sensor + relé + bomba funcionando juntos en banco de pruebas, con calibración | **[COMPLETAR]** requiere el hardware |
| TRL5: validación en entorno relevante | Prototipo integrado probado con suelo real y escenarios de humedad (Tabla 6 del doc. maestro: error de lectura, % de activaciones correctas, tiempo de respuesta, estabilidad) | **[COMPLETAR]** requiere pruebas con el prototipo físico |

Importante: el firmware no se ha ejecutado todavía en un ESP32 real (en este entorno solo se compiló la lógica y se
verificó la sintaxis del sketch). Los resultados de las secciones 4.2 y 4.3 deben salir de las pruebas físicas descritas en
`PLAN_PRUEBAS_Y_CALIBRACION.md`.

### 4.1 Resultados de las pruebas automáticas de la lógica
38 pruebas, 0 fallidas (`make test` en `/pruebas`). Cubren histéresis, ausencia de encendidos repetidos, tiempo máximo y
espera, falla de sensor, modos manual y parada, validación de umbrales, desbordamiento del contador `millis()` y conversión
del sensor. La simulación (`make sim`) usa un modelo de suelo ficticio: sirve para ejercitar el flujo completo, pero sus
valores **no son mediciones** y no se usan para afirmar ahorro de agua.

### 4.2 Calibración del sensor **[COMPLETAR]**
Valores ADC en seco y saturado, muestras gravimétricas y error absoluto medio frente a la humedad gravimétrica.

### 4.3 Pruebas en el entorno de validación **[COMPLETAR]**
Tabla con el formato de pruebas (escenario, fecha y hora, humedad inicial, respuesta esperada, respuesta observada,
observaciones), el porcentaje de activaciones y desactivaciones correctas, el tiempo de respuesta y la disponibilidad.
Si se compara el volumen aplicado o el tiempo de bombeo con un escenario de referencia, reportarlo solo si las
condiciones fueron comparables; de lo contrario declararlo como limitación, como dice el documento maestro.



## 6. Ajustes pendientes del documento maestro (Fase 3)

Al revisar el documento de la Fase 3 se detectaron inconsistencias que conviene corregir en la versión final (además de las recomendaciones del tutor):

- Numeración de tablas: en el cuerpo las tablas van de la 1 a la 10 (1 líneas de investigación, 2 antecedentes, 3 normas, 4 componentes, 5 instrumentos, 6 variables, 7 requerimientos, 8 cronograma, 9 recursos, 10 resultados), pero la Lista de tablas del inicio no incluye la Tabla 1 ni la 3 y desde la normas en adelante va desplazada una posición (normas figura como Tabla 4, componentes como 5, etc., hasta resultados como 11). Además hay referencias cruzadas erradas en el texto: "La Tabla 1 resume los antecedentes" (es la 2), las variables se citan como "Tabla 5" (es la 6), los requerimientos como "Tabla 6" (es la 7) y los recursos como "Tabla 8" (es la 9). En este documento se usa la numeración del cuerpo. Actualizar la Lista de tablas y las referencias antes de entregar.
- Corregir "confrimo" → "confirmo" en el anexo (b), si el anexo se vuelve a capturar.
- Tras construir el prototipo, actualizar la Tabla 9 (presupuesto) con los costos reales y la Tabla 4 (componentes) con los modelos definitivos.
