# Guion del video (máximo 10 minutos)

Requisitos de la guía: no más de 10 minutos, participantes con la cámara web encendida durante toda la grabación,
mostrar el manejo y el funcionamiento del prototipo. Ensayar una vez con cronómetro.

| Minuto | Contenido | Quién |
|---|---|---|
| 0:00–0:45 | Presentación del equipo, del proyecto y del problema (riego sin datos continuos del suelo) | Ambos, cámara encendida |
| 0:45–1:45 | Arquitectura: sensor → ESP32 → relé → bomba, y MQTT → tablero. Mostrar el diagrama del documento maestro | |
| 1:45–3:00 | El prototipo físico: componentes, conexiones, caja y separación control/potencia | |
| 3:00–4:00 | Código en GitHub: estructura, `control_riego.h`, pruebas automáticas (ejecutar `make test` y mostrar 0 fallidas) | |
| 4:00–5:00 | Calibración: valores seco y húmedo, comparación con la humedad gravimétrica | |
| 5:00–7:30 | Demostración: suelo seco → el relé enciende; al alcanzar el umbral superior apaga; modo manual y parada; desconectar el sensor y mostrar la falla segura | |
| 7:30–8:30 | Monitoreo MQTT: mensajes de estado y un comando remoto; mostrar el registro CSV | |
| 8:30–9:30 | Resultados medidos, limitaciones (calibración, comparación de agua si no fue posible) y trabajo futuro | |
| 9:30–10:00 | Cierre | |

Consejos: grabar la pantalla y la cámara a la vez, mostrar el Monitor Serie y el tablero, no mostrar contraseñas
(Wi-Fi o MQTT) en pantalla, y subir el video a una plataforma con enlace accesible para el tutor.
