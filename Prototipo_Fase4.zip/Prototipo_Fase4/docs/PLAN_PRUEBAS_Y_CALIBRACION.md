# Plan de pruebas y guía de calibración

Objetivo: obtener con el prototipo físico la evidencia de TRL5. Registrar todo en el formato de pruebas al final.
Antes de cada prueba con agua, revisar: conexiones secas, caja cerrada, fusible puesto y sin tensión de red.

## A. Calibración del sensor (hacer primero)

1. Cargar el firmware y abrir el Monitor Serie (115200).
2. Con el sensor al aire (seco), esperar unos segundos y enviar `cal_seco`. Con el sensor en una muestra del suelo de prueba
   saturado de agua (hasta la línea indicada del sensor), enviar `cal_humedo`. Enviar `estado` y anotar `seco` y `humedo`.
3. Verificar con el sensor en suelo de prueba: tomar una muestra del suelo cerca del sensor, pesarla (húmeda), secarla
   (horno o secado según el laboratorio disponible), pesarla (seca) y calcular la humedad gravimétrica
   (masa de agua / masa seca × 100). Comparar con el % que muestra `estado`.
4. Repetir con 5 o más muestras a distintos niveles de humedad. Calcular el error absoluto medio. Si el error es alto, anotar la
   limitación o ajustar la calibración (en el análisis estadístico del documento maestro se prevé un ajuste lineal).
5. Si hay más de un sensor, calibrar cada uno por separado y compararlos.

## B. Definir umbrales

Los umbrales vienen de partida en 30 % y 60 %: no son valores agronómicos. Definirlos con el diagnóstico (cultivo, suelo,
práctica del productor) y fijarlos con `umbral_inf N` y `umbral_sup N`. Fijar `tmax_min N` según el caudal de la bomba y
el tiempo que realmente tarda en subir la humedad en las pruebas. Anotar los valores usados.

## C. Pruebas funcionales (formato en la sección D)

| ID | Prueba | Cómo hacerla | Resultado esperado |
|---|---|---|---|
| 1.1 | Lectura periódica (RF1) | Dejar el sensor en suelo y observar `estado` varias veces; cambiar `intervalo_s` | Lecturas estables y coherentes con la humedad; el intervalo cambia |
| 1.2 | Validación de lectura (RNF3) | Desconectar el cable del sensor | Estado `FALLA_SENSOR`, relé apagado |
| 1.3 | Registro (RF5) | Dejar corriendo 10 min y enviar `volcar` | CSV con lecturas cada minuto, eventos y hora |
| 2.1 | Activa bajo el umbral inferior (RF3) | Con suelo seco o `umbral_inf` alto, ver el relé | Relé ON, estado `REGANDO` |
| 2.2 | Desactiva en el umbral superior (RF4) | Dejar regar hasta alcanzar el superior | Relé OFF, estado `REPOSO` |
| 2.3 | Histéresis (RF2) | Con humedad entre umbrales | No enciende ni apaga repetidamente |
| 2.4 | Manual y parada (RF7) | `modo MANUAL` y `modo PARADA` | Manual enciende; parada apaga de inmediato |
| 2.5 | Tiempo máximo (RNF3) | Bomba sin agua o `tmax_min 1` con suelo seco | `BLOQUEO_TIEMPO`, relé apagado y espera |
| 2.6 | Reinicio seguro | Reiniciar la placa (botón EN) con el riego encendido | El relé arranca apagado y los umbrales se conservan |
| 3.1 | Monitoreo MQTT (RF6) | Suscribirse a `riego/riego01/estado` | Mensaje JSON cada 30 s y en cada cambio |
| 3.2 | Comandos remotos | Publicar en `riego/riego01/cmd/modo` el valor `PARADA` | El riego se apaga; queda registrado el evento |
| 3.3 | Sin red | Apagar el Wi-Fi | El control y el registro continúan |
| 3.4 | Credenciales (RNF4) | Revisar que `secrets.h` no esté en GitHub y que el mensaje no identifique productores | Cumple |

## D. Formato de registro de pruebas

| ID | Escenario | Fecha y hora | Humedad inicial (%) | Respuesta esperada | Respuesta observada | ¿Cumple? | Observaciones |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Indicadores a calcular (Tabla 6 del documento maestro): error absoluto medio de lectura; porcentaje de activaciones y
desactivaciones correctas (correctas / totales de las pruebas); tiempo de respuesta (desde que cruza el umbral hasta que
cambia el relé; con intervalo de 10 s es de hasta ~10 s por diseño); porcentaje de tiempo operativo.

## E. Comparación del uso de agua (solo si es posible)

Solo si hay condiciones comparables: medir el volumen aplicado (recipiente graduado) o el tiempo de bombeo en el modo
automático y en un escenario de referencia (por ejemplo riego por horario fijo) durante periodos y condiciones similares.
Si no se puede, no afirmar ahorro; declararlo como limitación.
